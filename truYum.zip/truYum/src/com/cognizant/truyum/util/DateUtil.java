package com.cognizant.truyum.util;

import java.util.Date;

public class DateUtil
{
	public static Date convertToDate(String date)
	{
		Date convertedDate = null;
		
		return convertedDate;
	}
}
