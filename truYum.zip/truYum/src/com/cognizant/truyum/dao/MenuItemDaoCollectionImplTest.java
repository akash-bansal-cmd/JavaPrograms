package com.cognizant.truyum.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MenuItemDaoCollectionImplTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testMenuItemDaoCollection() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMenuItemListAdmin() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMenuItemListCustomer() {
		fail("Not yet implemented");
	}

	@Test
	public void testModifyMenuItem() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMenuItem() {
		fail("Not yet implemented");
	}

}
