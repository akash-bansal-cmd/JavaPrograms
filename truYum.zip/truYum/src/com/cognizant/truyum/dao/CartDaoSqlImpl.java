package com.cognizant.truyum.dao;

import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoSqlImpl implements CartDao {

	public CartDaoSqlImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addcartItem(long userId, long menuItemId) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<MenuItem> getAllcartItems(long userId) throws CartEmptyException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {
		// TODO Auto-generated method stub

	}

}
