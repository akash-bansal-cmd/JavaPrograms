package com.cognizant.truyum.dao;

import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public interface CartDao
{
	void addcartItem(long userId, long menuItemId);
	List<MenuItem>getAllcartItems(long userId) throws CartEmptyException;
	void removeCartItem (long userId, long menuItemId);
}