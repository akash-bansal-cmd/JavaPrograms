package com.cognizant.truyum.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MenuItemDaoSqlImplTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testMenuItemDaoSqlImpl() {
		fail("Not yet implemented");
	}

	@Test
	public final void testGetMenuItemListAdmin() {
		fail("Not yet implemented");
	}

	@Test
	public final void testGetMenuItemListCustomer() {
		fail("Not yet implemented");
	}

	@Test
	public final void testModifyMenuItem() {
		fail("Not yet implemented");
	}

	@Test
	public final void testGetMenuItem() {
		fail("Not yet implemented");
	}

}
