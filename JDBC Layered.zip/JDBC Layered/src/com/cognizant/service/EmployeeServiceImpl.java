package com.cognizant.service;

import static org.junit.Assert.assertTrue;

import java.util.List;

import com.cognizant.dao.EmployeeDao;
import com.cognizant.dao.EmployeeDaoImpl;
import com.cognizant.exception.EmployeeException;
import com.cognizant.model.Employee;

public class EmployeeServiceImpl implements EmployeeService
{
	private EmployeeDao employeeDao;
	
	
	public EmployeeServiceImpl() 
	{
		super();
		this.employeeDao = new EmployeeDaoImpl();
	}

	@Override
	public int insertEmployee(Employee employee) 
	{
		int status = 0;
		
		try
		{
			status = employeeDao.insertEmployee(employee);
		}catch(EmployeeException ee)
		{
			System.out.println(ee.getMessage());
			status = -1;
		}
		return status;
	}

	@Override
	public int updateEmployee(Employee employee) 
	{
		int status = 0;
		
		try
		{
			status = employeeDao.updateEmployee(employee);
		}catch(EmployeeException ee)
		{
			System.out.println(ee.getMessage());
			status = -1;
		}
		return status;
	}

	@Override
	public int deleteEmployee(int empid) 
	{
		int status = 0;
		try
		{
			status = employeeDao.deleteEmployee(empid);
		}
		catch(EmployeeException ee)
		{
			ee.printStackTrace();
		}
		return status;
	}

	@Override
	public List<Employee> viewEmployee() 
	{
		List<Employee>employeeList = null;
		
		try
		{
			employeeList= employeeDao.viewEmployee();
		}
		catch(EmployeeException ee)
		{
			ee.printStackTrace();
		}
		return employeeList;
	}

}
