package com.cognizant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.exception.EmployeeException;
import com.cognizant.helper.DBUtil;
import com.cognizant.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public int insertEmployee(Employee employee) throws EmployeeException {
		String sql = "INSERT INTO emp1 VALUES(?,?,?)";
		int status = 0;
		try(Connection connEmployee = DBUtil.createConnection();
			PreparedStatement pstEmployee = connEmployee.prepareStatement(sql);){
			
			pstEmployee.setInt(1, employee.getEmpid());
			pstEmployee.setString(2, employee.getName());
			pstEmployee.setFloat(3, employee.getSalary());
			
			status = pstEmployee.executeUpdate();
			
		}catch(ClassNotFoundException | SQLException excEmployee){
			throw new EmployeeException(excEmployee.getMessage());
		}
		return status;
	}

	@Override
	public int updateEmployee(Employee employee) throws EmployeeException {
		String sql = "UPDATE emp1 SET name=?, salary=? WHERE empid=?";
		int status = 0;
		try(Connection connEmployee = DBUtil.createConnection();
			PreparedStatement pstEmployee = connEmployee.prepareStatement(sql);){
			
			pstEmployee.setString(1, employee.getName());
			pstEmployee.setFloat(2, employee.getSalary());
			pstEmployee.setInt(3, employee.getEmpid());
						
			status = pstEmployee.executeUpdate();
			
		}catch(ClassNotFoundException | SQLException excEmployee){
			throw new EmployeeException(excEmployee.getMessage());
		}
		return status;
	}

	@Override
	public int deleteEmployee(int empid) throws EmployeeException {
		String sql = "DELETE FROM emp1 WHERE empid=?";
		int status = 0;
		try(Connection connEmployee = DBUtil.createConnection();
			PreparedStatement pstEmployee = connEmployee.prepareStatement(sql);){
			
			pstEmployee.setInt(1, empid);
						
			status = pstEmployee.executeUpdate();
			
		}catch(ClassNotFoundException | SQLException excEmployee){
			throw new EmployeeException(excEmployee.getMessage());
		}
		return status;
	}

	@Override
	public List<Employee> viewEmployee() throws EmployeeException {
		String sql = "SELECT empid, name, salary FROM emp1";
		List<Employee>employeeList = new ArrayList<>();
		
		Employee employee = null;
		
		ResultSet rsEmployee = null;
		
		
		try(Connection connEmployee = DBUtil.createConnection();
			PreparedStatement pstEmployee = connEmployee.prepareStatement(sql);){
			
			rsEmployee = pstEmployee.executeQuery();
			
			while(rsEmployee.next()){
				employee = new Employee();
				employee.setEmpid(rsEmployee.getInt("empid"));
				employee.setName(rsEmployee.getString("name"));
				employee.setSalary(rsEmployee.getFloat("salary"));
				
				employeeList.add(employee);
			}
			
		}catch(ClassNotFoundException | SQLException excEmployee){
			throw new EmployeeException(excEmployee.getMessage());
		}
		return employeeList;
	}

}
