package com.cognizant.client;

import java.util.List;

import com.cognizant.model.Employee;
import com.cognizant.service.EmployeeService;
import com.cognizant.service.EmployeeServiceImpl;

public class ClientEmployee 
{

	public static void main(String[] args) 
	{
		Employee employee = new Employee(10,"pqr", 50000);
		
		EmployeeService empService = new EmployeeServiceImpl();
		
		empService.insertEmployee(employee);
		
		employee.setSalary(60000);
		empService.updateEmployee(employee);
			
		List<Employee>employeeList = empService.viewEmployee();
		System.out.println("All Records");
		for(Employee employee2 : employeeList)
		{
			System.out.println(employee2);
		}
		
		empService.deleteEmployee(10);
		
		System.out.println("\n=============================================\nAll records");
		
		employeeList = empService.viewEmployee();
		
		for(Employee employee2 : employeeList)
		{
			System.out.println(employee2);
		}
		
		
		
		}

	}

